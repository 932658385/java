@FunctionalInterface
interface JogoAction {
    void executar(Jogador jogador, Equipa equipe);
}