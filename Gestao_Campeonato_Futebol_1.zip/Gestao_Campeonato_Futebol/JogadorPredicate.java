@FunctionalInterface
interface JogadorPredicate {
    boolean test(Jogador jogador);
}