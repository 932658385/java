@FunctionalInterface
interface JogadorAction {
    void executar(Jogador jogador);
}