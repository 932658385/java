package entidade;

public @interface Override {

}
