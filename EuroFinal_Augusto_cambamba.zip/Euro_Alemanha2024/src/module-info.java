module Euro_Alemanha2024 {
    requires transitive java.sql;
    exports entidade;
    exports DAO;
    exports conexao;
}
